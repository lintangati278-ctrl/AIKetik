# AIKetik V2

V2 menambahkan jalur AI nyata melalui backend HTTPS.

## Penting
API key tidak disimpan di aplikasi Android. Jalankan backend di server dan isi `AI_ENDPOINT` pada `AIKetikService.java` dengan URL HTTPS.

## Fitur
- AI writing
- Rewrite teks terpilih
- Translate ke English
- Voice UI
- Keyboard QWERTY
- Backend Node.js

## APK/AAB
Android Studio: Build > Generate App Bundles or APKs.

GitHub Actions dapat dipakai untuk build otomatis setelah project di-push ke repository.
