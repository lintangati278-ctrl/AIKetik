# AIKetik — FINAL 1.0.0

AI keyboard Android dengan QWERTY, AI Writing, Rewrite, Translate, dan Style.

## Yang sudah siap
- Project Android native
- Keyboard InputMethodService
- Halaman aktivasi/pemilihan keyboard
- Pengaturan URL backend AI dari aplikasi
- API key tidak ditanam di APK
- Backend Node.js starter di `aiketik-backend/`
- GitHub Actions untuk membangun debug APK dan AAB

## Mengaktifkan AI
1. Deploy `aiketik-backend` ke server HTTPS.
2. Isi `OPENAI_API_KEY` sebagai secret/environment variable server.
3. Jalankan backend dan pastikan `/health` aktif.
4. Buka AIKetik > Pengaturan AI.
5. Isi URL `https://domain-anda.com/v1/ai`.
6. Simpan, aktifkan AIKetik sebagai keyboard, lalu pilih AIKetik.

## Build APK/AAB gratis
Project ini menyertakan `.github/workflows/android.yml`. Upload ke GitHub, buka tab Actions, jalankan workflow `Build AIKetik APK AAB`. Hasil build akan tersedia sebagai artifact.

## Penting
- APK/AAB release bertanda tangan (signed) tetap memerlukan keystore milik pemilik aplikasi untuk distribusi produksi/Play Store.
- Jangan pernah menaruh API key OpenAI di source Android atau APK.
- Backend produksi sebaiknya memakai HTTPS, authentication, rate limit, dan logging yang tidak menyimpan isi teks sensitif.
