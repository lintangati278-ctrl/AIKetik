# AIKetik V1

AIKetik adalah prototipe Android keyboard AI dengan tema dark premium biru-ungu.

## Fitur V1
- Android Input Method (keyboard)
- QWERTY Indonesia
- Tombol AI, Tulis, Tulis ulang, Translate, Voice
- Shift, backspace, enter, emoji, space
- Halaman aktivasi dan pemilihan keyboard

> Catatan: tombol AI saat ini adalah UI/prototipe lokal. Untuk AI sungguhan, sambungkan backend/API AI pada V2. Jangan menaruh API key rahasia langsung di aplikasi.

## Membuat APK + AAB
Buka project ini di Android Studio versi terbaru.

- APK debug: `assembleDebug`
- AAB debug: `bundleDebug`
- Untuk Play Store gunakan **release AAB** yang ditandatangani dengan keystore milik pengembang.

## Build otomatis gratis dengan GitHub Actions
Upload folder project ke repository GitHub, buka tab **Actions**, pilih **Build AIKetik APK AAB**, lalu **Run workflow**. Hasil APK dan AAB tersedia sebagai Artifacts.
