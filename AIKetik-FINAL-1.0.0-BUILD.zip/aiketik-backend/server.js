const http = require('http');
const PORT = process.env.PORT || 8080;
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || 'gpt-5.6';
const MAX_BODY = 32 * 1024;
function send(res, code, obj){res.writeHead(code, {'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*'});res.end(JSON.stringify(obj));}
function body(req){return new Promise((resolve,reject)=>{let s=''; req.on('data',d=>{s+=d; if(s.length>MAX_BODY){reject(new Error('request_too_large')); req.destroy();}}); req.on('end',()=>{try{resolve(JSON.parse(s||'{}'))}catch(e){reject(new Error('invalid_json'))})})})}
async function main(req,res){
 if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST,GET,OPTIONS'});return res.end();}
 if(req.method==='GET' && req.url==='/health') return send(res,200,{ok:true,service:'AIKetik AI backend'});
 if(req.method!=='POST' || req.url!=='/v1/ai') return send(res,404,{error:'not_found'});
 if(!API_KEY) return send(res,500,{error:'OPENAI_API_KEY is not configured'});
 try{
  const x=await body(req); const instruction=String(x.instruction||'').slice(0,4000); const text=String(x.text||'').slice(0,12000);
  if(!instruction || !text) return send(res,400,{error:'instruction_and_text_required'});
  const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${API_KEY}`},body:JSON.stringify({model:MODEL,input:[{role:'system',content:'You are AIKetik, a concise Indonesian writing assistant. Return only the final text. Preserve meaning. Do not add quotation marks.'},{role:'user',content:`${instruction}\n\nText:\n${text}`}],max_output_tokens:600})});
  const j=await r.json(); if(!r.ok) return send(res,r.status,{error:j});
  const result=j.output_text || (j.output||[]).flatMap(o=>o.content||[]).map(c=>c.text||'').join('');
  return send(res,200,{result:String(result).trim()});
 }catch(e){return send(res,e.message==='invalid_json'?400:500,{error:e.message})}
}
http.createServer(main).listen(PORT,()=>console.log(`AIKetik backend listening on ${PORT}`));
