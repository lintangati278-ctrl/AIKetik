# AIKetik AI Backend

Minimal HTTPS-ready Node.js backend for AIKetik.

Environment:
- `OPENAI_API_KEY` — required, server-side only
- `OPENAI_MODEL` — optional model name
- `PORT` — optional, default 8080

Endpoints:
- `GET /health`
- `POST /v1/ai` body: `{ "instruction": "...", "text": "..." }`

Never ship the API key inside the Android app.
