# AIKetik V3 — Premium AI Keyboard

V3 fokus pada pengalaman keyboard premium dan alur AI yang lebih nyata.

## Fitur
- Keyboard QWERTY dark premium
- AI, Tulis, Ulang, Translate, dan Gaya
- AI menggunakan teks terpilih; jika tidak ada seleksi, mengambil konteks teks sebelum kursor
- Backend AI terpisah; API key tidak ditanam di APK
- Voice input melalui mekanisme Android/keyboard host

## Mengaktifkan AI sungguhan
1. Deploy folder `aiketik-backend` ke server HTTPS.
2. Set `OPENAI_API_KEY` sebagai environment variable di server.
3. Set `OPENAI_MODEL` sesuai model yang tersedia pada akun/API Anda.
4. Ganti `AI_ENDPOINT` di `AIKetikService.java` dengan URL HTTPS backend.
5. Build APK/AAB release dan lakukan pengujian di perangkat.

## Keamanan
Jangan memasukkan API key langsung ke source Android atau APK. API key hanya boleh berada di environment server.
