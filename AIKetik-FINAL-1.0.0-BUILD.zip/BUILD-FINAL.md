# AIKetik 1.0.0 — Final Build

## Build APK/AAB
1. Upload this project to a GitHub repository.
2. Open **Actions**.
3. Select **Build AIKetik APK AAB**.
4. Click **Run workflow**.
5. Wait for the build to finish.
6. Open the workflow run and download artifact **AIKetik-1.0.0-builds**.

The artifact contains:
- Debug APK — installable for testing.
- Debug AAB — testing bundle.
- Release APK — unsigned release build.
- Release AAB — unsigned release bundle.

## Important
The release APK/AAB are unsigned because no signing key is included in the source project. For Google Play, create a secure release keystore and configure signing in CI. Never commit the keystore or passwords.

## AI backend
Set a real HTTPS backend URL in `AIKetikService.java` by replacing the placeholder `AI_ENDPOINT`. Keep the OpenAI API key on the server only.
