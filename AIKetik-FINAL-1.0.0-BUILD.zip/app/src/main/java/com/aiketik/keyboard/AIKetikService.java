package com.aiketik.keyboard;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executors;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.*;

public class AIKetikService extends InputMethodService {
    private final int NAVY = Color.rgb(7, 17, 39);
    private final int KEY = Color.rgb(25, 38, 74);
    private final int ACCENT = Color.rgb(65, 184, 255);
    private final int WHITE = Color.WHITE;
    private boolean shift = false;
    private static final String DEFAULT_AI_ENDPOINT = "";

    @Override public View onCreateInputView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(6, 6, 6, 6);
        root.setBackgroundColor(NAVY);

        LinearLayout tools = new LinearLayout(this);
        String[] actions = {"✨ AI", "✍ Tulis", "🔄 Ulang", "🌐 EN", "😊 Gaya"};
        for (String label : actions) {
            Button b = makeButton(label, 11);
            b.setOnClickListener(v -> aiAction(label));
            tools.addView(b, new LinearLayout.LayoutParams(0, 48, 1));
        }
        root.addView(tools);

        String[][] rows = {
            {"Q","W","E","R","T","Y","U","I","O","P"},
            {"A","S","D","F","G","H","J","K","L"},
            {"⇧","Z","X","C","V","B","N","M","⌫"},
            {"123","😊","MIC","SPACE",".","↵"}
        };
        for (String[] rowKeys : rows) {
            LinearLayout row = new LinearLayout(this);
            for (String key : rowKeys) {
                Button b = makeButton(key, key.equals("SPACE") ? 10 : 12);
                b.setOnClickListener(v -> press(((Button)v).getText().toString()));
                float weight = key.equals("SPACE") ? 2.5f : (key.equals("123") || key.equals("MIC") ? 1.2f : 1f);
                row.addView(b, new LinearLayout.LayoutParams(0, 54, weight));
            }
            root.addView(row);
        }
        return root;
    }

    private Button makeButton(String text, float size) {
        Button b = new Button(this);
        b.setText(text); b.setTextColor(WHITE); b.setTextSize(size); b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        GradientDrawable bg = new GradientDrawable(); bg.setColor(KEY); bg.setCornerRadius(14);
        b.setBackground(bg); b.setPadding(1, 0, 1, 0);
        return b;
    }

    private void press(String s) {
        InputConnection ic = getCurrentInputConnection(); if (ic == null) return;
        switch (s) {
            case "SPACE": ic.commitText(" ", 1); break;
            case "⌫": ic.deleteSurroundingText(1, 0); break;
            case "↵": ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER)); break;
            case "⇧": shift = !shift; Toast.makeText(this, shift ? "Shift ON" : "Shift OFF", Toast.LENGTH_SHORT).show(); break;
            case "123": Toast.makeText(this, "Mode angka segera hadir", Toast.LENGTH_SHORT).show(); break;
            case "😊": ic.commitText("😊", 1); break;
            case "MIC": Toast.makeText(this, "Voice input siap di V2", Toast.LENGTH_SHORT).show(); break;
            default: ic.commitText(shift ? s.toUpperCase() : s.toLowerCase(), 1); if (shift) shift = false;
        }
    }

    private void aiAction(String action) {
        InputConnection ic = getCurrentInputConnection(); if (ic == null) return;
        String prompt;
        if (action.contains("Tulis")) prompt = "Buatkan pesan profesional berdasarkan konteks pengguna.";
        else if (action.contains("Ulang")) prompt = "Tulis ulang teks yang dipilih agar lebih jelas, natural, dan profesional.";
        else if (action.contains("EN")) prompt = "Terjemahkan teks yang dipilih ke bahasa Inggris natural.";
        else if (action.contains("AI")) prompt = "Bantu pengguna membuat teks yang sesuai konteks.";
        else { prompt = "Buat versi yang lebih ramah, natural, dan ringkas dari teks ini."; }
        CharSequence selected = ic.getSelectedText(0);
        String text = selected == null ? "" : selected.toString();
        if (text.trim().isEmpty()) {
            CharSequence before = ic.getTextBeforeCursor(500, 0);
            text = before == null ? "" : before.toString();
        }
        if (text.trim().isEmpty()) text = "Tolong buatkan teks yang sesuai konteks percakapan.";
        final String input = text;
        Toast.makeText(this, "AI sedang memproses…", Toast.LENGTH_SHORT).show();
        Executors.newSingleThreadExecutor().execute(() -> {
            String result = callBackend(prompt, input);
            new Handler(Looper.getMainLooper()).post(() -> {
                if (result == null || result.trim().isEmpty()) {
                    Toast.makeText(this, "Backend AI belum terhubung", Toast.LENGTH_LONG).show();
                } else {
                    InputConnection current = getCurrentInputConnection();
                    if (current != null && selected != null && selected.length() > 0) current.commitText(result, 1);
                    else if (current != null) current.commitText(result, 1);
                }
            });
        });
    }

    private String callBackend(String instruction, String text) {
        String endpoint = getSharedPreferences("aiketik", MODE_PRIVATE).getString("ai_endpoint", DEFAULT_AI_ENDPOINT);
        if (endpoint == null || endpoint.trim().isEmpty()) return null;
        HttpURLConnection c = null;
        try {
            URL u = new URL(endpoint); c = (HttpURLConnection)u.openConnection();
            c.setRequestMethod("POST"); c.setConnectTimeout(8000); c.setReadTimeout(15000);
            c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            String body = "{\"instruction\":\"" + json(instruction) + "\",\"text\":\"" + json(text) + "\"}";
            try(OutputStream os=c.getOutputStream()){os.write(body.getBytes("UTF-8"));}
            if(c.getResponseCode()<200 || c.getResponseCode()>=300) return null;
            try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"))){
                StringBuilder out=new StringBuilder(); String line; while((line=r.readLine())!=null) out.append(line); return parseResult(out.toString());
            }
        } catch(Exception e){ return null; } finally { if(c!=null)c.disconnect(); }
    }
    private String json(String s){ return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n"); }
    private String parseResult(String s){ int a=s.indexOf("\"result\""); if(a<0)return null; a=s.indexOf(':',a)+1; while(a<s.length()&&Character.isWhitespace(s.charAt(a)))a++; if(a<s.length()&&s.charAt(a)=='\"')a++; int b=s.indexOf('\"',a); return b>0?s.substring(a,b):null; }

}
