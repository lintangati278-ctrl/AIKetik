package com.aiketik.keyboard;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView label(String s, float size) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); t.setPadding(dp(4),dp(8),dp(4),dp(8)); return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setTextSize(15);
        GradientDrawable g = new GradientDrawable(); g.setColor(Color.rgb(24,36,71)); g.setCornerRadius(dp(16)); b.setBackground(g); return b;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(18),dp(20),dp(24)); root.setBackgroundColor(Color.rgb(7,17,39));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.aiketik_logo); logo.setAdjustViewBounds(true); content.addView(logo,new LinearLayout.LayoutParams(-1,dp(190)));
        TextView title=label("AIKetik",30); title.setGravity(Gravity.CENTER); title.setTypeface(null,1); content.addView(title);
        TextView sub=label("Ketik lebih pintar dengan AI.",16); sub.setGravity(Gravity.CENTER); sub.setTextColor(Color.LTGRAY); content.addView(sub);

        content.addView(label("Pengaturan AI",20));
        TextView help=label("Masukkan URL endpoint backend HTTPS. API key tidak disimpan di aplikasi.",14); help.setTextColor(Color.LTGRAY); content.addView(help);
        EditText endpoint=new EditText(this); endpoint.setHint("https://domain-anda.com/v1/ai"); endpoint.setHintTextColor(Color.GRAY); endpoint.setTextColor(Color.WHITE); endpoint.setSingleLine(true);
        String saved=getSharedPreferences("aiketik",MODE_PRIVATE).getString("ai_endpoint",""); endpoint.setText(saved); content.addView(endpoint,new LinearLayout.LayoutParams(-1,dp(58)));
        Button save=button("Simpan Endpoint AI"); save.setOnClickListener(v->{getSharedPreferences("aiketik",MODE_PRIVATE).edit().putString("ai_endpoint",endpoint.getText().toString().trim()).apply(); android.widget.Toast.makeText(this,"Endpoint tersimpan",android.widget.Toast.LENGTH_SHORT).show();}); content.addView(save);

        Button activate=button("Aktifkan Keyboard AIKetik"); activate.setOnClickListener(v->startActivity(new Intent("android.settings.INPUT_METHOD_SETTINGS"))); content.addView(activate);
        Button choose=button("Pilih AIKetik sebagai keyboard"); choose.setOnClickListener(v->((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).showInputMethodPicker()); content.addView(choose);
        TextView info=label("V1.0.0 • QWERTY • AI Writing • Rewrite • Translate • Style",13); info.setTextColor(Color.GRAY); info.setGravity(Gravity.CENTER); content.addView(info);
        scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
}
